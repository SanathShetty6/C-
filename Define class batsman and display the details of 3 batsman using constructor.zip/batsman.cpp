/*
NAME: SANATH SHETTY .P.
DATE: 16/06/2024
DESCRIPTION: Define class batsman and display the details of 3 batsman using constructor
SAMPLE EXECUTION:
Batsman 1 Details:
Name: Virat Kohli
Age: 32
Country: India
Total Runs Scored: 12169
Average:  60.18
Number of Matches Played: 215

Batsman 2 Details:
Name: Steve Smith
Age: 32
Country: Australia
Total Runs Scored: 7540
Average:  55.1
Number of Matches Played: 191

Batsman 3 Details:
Name: Kane Williamson
Age: 30
Country: New Zealand
Total Runs Scored: 7115
Average:  49.9
Number of Matches Played: 195

*/

#include <iostream>
using namespace std;

class Batsman {
private:
    string name;       // Name of the batsman
    int age;           // Age of the batsman
    string country;    // Country of the batsman
    int total_runs;    // Total runs scored by the batsman
    float avg;         //Average runs
    int no_of_matches; // Number of matches played by the batsman

public:
    // Constructor to initialize the batsman details
    Batsman(string n, int a, string c, int tr , float av , int m ) : name(n), age(a), country(c), total_runs(tr) , avg(av) , no_of_matches(m){}

    // Method to display the details of the batsman
    void display_details() {
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Country: " << country << endl;
        cout << "Total Runs Scored: " << total_runs << endl;
        cout << "Average:  " << avg << endl;
        cout << "Number of Matches Played: " << no_of_matches << endl << endl;
    }
};

int main() {
    // Creating instances of Batsman class
    Batsman batsman1("Virat Kohli", 32, "India", 12169 , 60.18 , 215);
    Batsman batsman2("Steve Smith", 32, "Australia", 7540, 55.10 , 191);
    Batsman batsman3("Kane Williamson", 30, "New Zealand", 7115 , 49.90 , 195);

    // Displaying details of batsmen
    cout << "Batsman 1 Details:" << endl;
    batsman1.display_details();

    cout << "Batsman 2 Details:" << endl;
    batsman2.display_details();

    cout << "Batsman 3 Details:" << endl;
    batsman3.display_details();

    return 0;
}


