/*
NAME: SANATH SHETTY P
DATE: 10/06/2024
DESCRIPTION:
Program to swap two numbers using reference variables.
*/

#include <iostream>
using namespace std;

// Function to swap two numbers using reference variables
void swap(int &a, int &b) {
    int temp = a;
    a = b;
    b = temp;
}

int main() {
    int num1, num2;

    // Prompt user to enter two numbers
    cout << "Enter 2 numbers: ";
    cin >> num1 >> num2;

    // Display numbers before swapping
    cout << "Before swap: " << num1 << " " << num2 << endl;

    // Call the swap function
    swap(num1, num2);

    // Display numbers after swapping
    cout << "After swap: " << num1 << " " << num2 << endl;

    return 0;
}

