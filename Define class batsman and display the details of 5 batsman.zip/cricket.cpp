/*
NAME: SANATH SHETTY P
DATE: 10/06/2024
DESCRIPTION: Define class batsman and display the details of 5 batsman
SAMPLE EXECUTION:
Enter the details of Batsman 1 : 18 virat 91 11 8148 
Enter the details of Batsman 2 : 45 rohith 91 10 4500
Enter the details of Batsman 3 : 55 sachin 214 15 15151
Enter the details of Batsman 4 : 07 dhoni 141 8 5000
*****************************
Batsman 1 details :
Batsman Number : 18
Batsman Name : virat
Number of innings :  91
Notouts : 11
Runs : 8148
Average : 101
*****************************
Batsman 2 details :
Batsman Number : 45
Batsman Name : rohith
Number of innings :  91
Notouts : 10
Runs : 4500
Average : 55
*****************************
Batsman 3 details :
Batsman Number : 55
Batsman Name : sachin
Number of innings :  214
Notouts : 15
Runs : 15151
Average : 76
*****************************
Batsman 4 details :
Batsman Number : 7
Batsman Name : dhoni
Number of innings :  141
Notouts : 8
Runs : 5000
Average : 37
*/

#include <iostream>
using namespace std;

class batsman
{
public:
    int BatsmanNum;
    char Batsman[20];
    int innings;
    int notout;
    int runs;
    float batavg;

    void Calculateavg()
    {
        batavg = runs / (innings - notout);
    }

    void display_details()
    {
        cout << "Batsman Number : " << BatsmanNum << endl;
        cout << "Batsman Name : " << Batsman << endl;
        cout << "Number of innings :  " << innings << endl;
        cout << "Notouts : " << notout << endl;
        cout << "Runs : " << runs << endl;
        cout << "Average : " << batavg << endl;
    }
};

int main()
{
    batsman bt1, bt2, bt3, bt4;

    cout << "Enter the details of Batsman 1 : ";
    cin >> bt1.BatsmanNum >> bt1.Batsman >> bt1.innings >> bt1.notout >> bt1.runs;

    bt1.Calculateavg();

    cout << "Enter the details of Batsman 2 : ";
    cin >> bt2.BatsmanNum >> bt2.Batsman >> bt2.innings >> bt2.notout >> bt2.runs;

    bt2.Calculateavg();

    cout << "Enter the details of Batsman 3 : ";
    cin >> bt3.BatsmanNum >> bt3.Batsman >> bt3.innings >> bt3.notout >> bt3.runs;

    bt3.Calculateavg();

    cout << "Enter the details of Batsman 4 : ";
    cin >> bt4.BatsmanNum >> bt4.Batsman >> bt4.innings >> bt4.notout >> bt4.runs;

    bt4.Calculateavg();

    cout << "*****************************" << endl;
    cout << "Batsman 1 details :" << endl;
    bt1.display_details();

    cout << "*****************************" << endl;
    cout << "Batsman 2 details :" << endl;
    bt2.display_details();

    cout << "*****************************" << endl;
    cout << "Batsman 3 details :" << endl;
    bt3.display_details();

    cout << "*****************************" << endl;
    cout << "Batsman 4 details :" << endl;
    bt4.display_details();

    return 0;
}