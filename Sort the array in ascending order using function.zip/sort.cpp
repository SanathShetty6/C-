/*
/*
NAME: SANATH SHETTY .P.
DATE: 07/06/2024
DESCRIPTION: Sort the array in ascending order using function
SAMPLE EXECUTION:
Case 1:
Enter array size: 5
Enter array elements: 2 1 3 5 4
Sorted array elements: 1 2 3 4 5

Case 2:
Enter array size: 5
Enter array elements: 7 1 4 1 4
Sorted array elements: 1 1 4 4 7
*/
*/
#include <iostream>
using namespace std;

void read_array(int arr[], int size);
void sort_array(int arr[], int size);
void print_array(int arr[], int size);

int main()
{
    int size;
    cout << "Enter array size: ";
    cin >> size;
    int arr[size];
    read_array(arr, size);
    sort_array(arr, size);
    print_array(arr, size);
    return 0;
}

void read_array(int arr[], int size)
{
    cout << "Enter array elements: ";
    for (int i = 0; i < size; i++)
    {
        cin >> arr[i];
    }
}

void sort_array(int arr[], int size)
{
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = 0; j < size - i - 1; j++)
        {
            if (arr[j] > arr[j + 1])
            {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void print_array(int arr[], int size)
{
    cout << "Sorted array elements: ";
    for (int i = 0; i < size; i++)
    {
        cout << arr[i] << " ";
    }
    cout << endl;
}