/*
NAME: SANATH SHETTY .P.
DATE: 07/06/2024
DESCRIPTION: FIND MAXIMUM OF 2 NUMBERS
SAMPLE EXECUTION:
Input    : 7 10
Output : maximum = 10
*/
#include <iostream>
using namespace std;
int main()
{
	int n1,n2,max;
	//Enter the value for two number
	cout << "Enter the value for two numbers: " ;
	cin >> n1 >> n2 ;
	max = n1 > n2 ? n1 : n2;
	cout << "The maximum number is " << max << endl ;
	return 0;
}

