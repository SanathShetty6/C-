/*
NAME: SANATH SHETTY P
DATE: 09/06/2024
DESCRIPTION:
SAMPLE EXECUTION:

Case 1:
Enter the details of student 1: 100 Rama 55.5 89.5

Enter the details of student 2: 101 Ravi 60 80

Student 1:

Id: 100

Name: Rama

Marks: 55.5
Attendance: 89.5



Student 2

Id: 101

Name: Ravi

Marks: 60
Attendance: 80


*/

#include <iostream>
using namespace std;

class student
{
public:
    int id;
    string name;
    float marks;
    double attn;

    void display_details()
    {
        cout << "ID: " << id << endl;
        cout << "Name: " << name << endl;
        cout << "Marks: " << marks << endl;
        cout << "Attendance: " << attn << endl;
    }
};

int main()
{
    student st1, st2;

    cout << "Enter the details of student 1";
    cin >> st1.id >> st1.name >> st1.marks >> st1.attn;

    cout << "Enter the details of student 2";
    cin >> st2.id >> st2.name >> st2.marks >> st2.attn;

    cout << "*****************************" << endl;
    cout << "Student 1 details :" << endl;
    st1.display_details();

    cout << "*****************************" << endl;
    cout << "Student 2 details :" << endl;
    st2.display_details();

    return 0;
}