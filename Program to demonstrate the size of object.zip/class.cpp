/*
NAME: SANATH SHETTY P
DATE: 09/06/2024
DESCRIPTION: Program to demonstrate the size of object
*/
#include <iostream>
using namespace std;

class Student {
public:
    int id;
    double attendance;
    float marks;

    void display_data() {
        cout << "ID: " << id << endl;
        cout << "Attendance: " << attendance << endl;
        cout << "Marks: " << marks << endl;
    }
};

int main() {
    // Create an object of Student
    Student student;
    
    // Assign values to the object
    student.id = 1;
    student.attendance = 95;
    student.marks = 88.5;

    // Display the data
    student.display_data();

    // Display the size of the object
    cout << "Size of Student object: " << sizeof(student) << " bytes" << endl;

    return 0;
}
